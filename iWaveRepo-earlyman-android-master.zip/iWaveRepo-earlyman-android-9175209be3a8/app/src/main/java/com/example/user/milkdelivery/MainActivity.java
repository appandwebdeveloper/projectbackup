package com.example.user.milkdelivery;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button mSignINButton;
    private EditText mUsernameEditText, mPasswordEditText;
    private TextView mUsernameTextView, mPasswordTextView, mSignUpTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mPasswordEditText = findViewById(R.id.passwordEditText);
        mSignINButton = findViewById(R.id.signInButton);
        mUsernameEditText = findViewById(R.id.usernameEditText);
        mPasswordTextView = findViewById(R.id.usernameTextView);
        mUsernameTextView = findViewById(R.id.passwordTextView);
        mSignUpTextView = findViewById(R.id.signUpTextView);

        mUsernameTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mUsernameEditText.setText("Sahana.b@inspiringwave.in");
                mPasswordEditText.setText("iwave123");
            }
        });
        mUsernameEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mUsernameEditText.setText("Sahana.b@inspiringwave.in");
                mPasswordEditText.setText("iwave123");
            }
        });
        mPasswordTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mUsernameEditText.setText("Sahana.b@inspiringwave.in");
                mPasswordEditText.setText("iwave123");
            }
        });
        mPasswordEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mUsernameEditText.setText("Sahana.b@inspiringwave.in");
                mPasswordEditText.setText("iwave123");
            }
        });
        mSignINButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(mUsernameEditText.getText().toString(), mPasswordEditText.getText().toString());


            }
        });
        mSignUpTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openSecond = new Intent(MainActivity.this, SignUpActivity.class);
                startActivity(openSecond);
            }
        });
    }

    private void validate(String name, String password) {
        if (name.equals("Sahana.b@inspiringwave.in") && password.equals("iwave123")) {
            Intent openSecond = new Intent(MainActivity.this, SecondActivity.class);
            startActivity(openSecond);
        }
    }
}

