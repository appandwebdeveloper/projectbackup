package com.example.user.milkdelivery;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AddAddress extends AppCompatActivity {
    private Button mNextButton;
    TextView mSignInTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_address);

        mNextButton = findViewById(R.id.nextButton);
        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openSecond = new Intent(AddAddress.this, EnterMobileNo.class);
                startActivity(openSecond);
            }
        });
        mSignInTextView = findViewById(R.id.signInTextView);
        mSignInTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openSecond = new Intent(AddAddress.this, MainActivity.class);
                startActivity(openSecond);
            }
        });
    }
}
