package com.example.user.milkdelivery.Activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.user.milkdelivery.R;

public class AddAddress extends Activity {
    private Button mNextButton;
    private TextView mSignInTextView;
    private ImageView mBackNavigationImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_address);
        mBackNavigationImageView = findViewById(R.id.backNavigationImageView);
        mNextButton = findViewById(R.id.nextButton);
        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(AddAddress.this, EnterMobileNo.class));
            }
        });
        mSignInTextView = findViewById(R.id.signInTextView);
        mSignInTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(AddAddress.this, MainActivity.class));
            }
        });
        mBackNavigationImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddAddress.this, SignUpActivity.class));
            }
        });
    }
}
