package com.example.user.milkdelivery;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SignUpActivity extends AppCompatActivity {
    private Button mNextButton;
    private TextView mSignInTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        mSignInTextView = findViewById(R.id.signInTextView);
        mNextButton = findViewById(R.id.nextButton);

        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openSecond = new Intent(SignUpActivity.this, AddAddress.class);
                startActivity(openSecond);
                finish();
            }
        });
        mSignInTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent open = new Intent(SignUpActivity.this, MainActivity.class);
                startActivity(open);
                finish();
            }
        });

    }

}
