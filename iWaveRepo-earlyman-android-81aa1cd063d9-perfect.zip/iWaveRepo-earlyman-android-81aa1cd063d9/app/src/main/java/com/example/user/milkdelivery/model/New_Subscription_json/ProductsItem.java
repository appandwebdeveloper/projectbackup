package com.example.user.milkdelivery.model.New_Subscription_json;


import com.google.gson.annotations.SerializedName;


public class ProductsItem{

	@SerializedName("image")
	public String image;

	@SerializedName("type")
	public String type;
}