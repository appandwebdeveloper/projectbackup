package com.example.user.milkdelivery.Adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.user.milkdelivery.R;
import com.example.user.milkdelivery.model.Orders_Dealers.Dealers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by User on 4/24/2018.
 */

public class DealersAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<Object> mOrdersList = new ArrayList<>();
    private static final int DEALERS_VIEW_TYPE = 1;
    public void setData(List<Object> OrdersList) {
        this.mOrdersList = OrdersList;
        notifyDataSetChanged();    }

    @Override
    public int getItemViewType(int position) {
              if(mOrdersList.get(position) instanceof Dealers)
        return DEALERS_VIEW_TYPE;
                  return 0;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                if(viewType==DEALERS_VIEW_TYPE)
                    return  new DealersViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_orders_dealers,parent,false));
    return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
                 if(holder instanceof DealersViewHolder)
                     ((DealersViewHolder) holder).setData((Dealers) mOrdersList.get(position));
    }

    @Override
    public int getItemCount() {
        return mOrdersList.size();
    }

    public class DealersViewHolder extends RecyclerView.ViewHolder {
        private TextView mDealersNameTextView;
        private CircleImageView mProfileImage;
        private EditText mDealerNumberEditText;
        private View mLayout;

        public DealersViewHolder(View itemView) {
            super(itemView);
            mLayout = itemView;
            mDealersNameTextView = itemView.findViewById(R.id.dealerNameTextView);
            mDealerNumberEditText = itemView.findViewById(R.id.dealerNumberEditText);
            mProfileImage = itemView.findViewById(R.id.profileImage);
        }

        public void setData(Dealers dealers) {
            mDealerNumberEditText.setText(dealers.phoneNumber);
            mDealersNameTextView.setText(dealers.personName);
            Glide.with(mProfileImage.getContext()).load(dealers.imageUrl).into(mProfileImage);

        }

    }
}
