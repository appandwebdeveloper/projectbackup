package com.example.user.milkdelivery.model.Orders_Dealers;


import com.google.gson.annotations.SerializedName;


public class TomorrowsOrder {

	@SerializedName("date")
	public String date;

	@SerializedName("quantity")
	public int quantity;

	@SerializedName("price")
	public String price;

	@SerializedName("imageUrl")
	public String imageUrl;

	@SerializedName("name")
	public String name;

	@SerializedName("neighbourInfo")
	public String neighbourInfo;
}