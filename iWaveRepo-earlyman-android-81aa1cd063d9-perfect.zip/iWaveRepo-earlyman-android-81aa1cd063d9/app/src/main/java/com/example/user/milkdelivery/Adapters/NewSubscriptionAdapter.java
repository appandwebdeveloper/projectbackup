package com.example.user.milkdelivery.Adapters;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.user.milkdelivery.R;
import com.example.user.milkdelivery.model.New_Subscription_json.ProductsItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by User on 3/8/2018.
 */

public class NewSubscriptionAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<Object> items = new ArrayList<>();
    private static final int IMAGE_PRODUCT_VIEW_TYPE = 1;
    private static final int HEADER_VIEW_TYPE = 0;

    public void setData(List<Object> items) {
        this.items = items;
        notifyDataSetChanged();
    }

    //this method for check getting  viewtype and pass that viewtype to particular viewholder
    @Override
    public int getItemViewType(int position) {

        if (items.get(position) instanceof String) {
            return HEADER_VIEW_TYPE;
        } else if (items.get(position) instanceof ProductsItem) {
            return IMAGE_PRODUCT_VIEW_TYPE;
        }
            return -1;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == HEADER_VIEW_TYPE) {
            return new HeaderViewHolder(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.header_newsubscription, parent, false));
        } else if (viewType == IMAGE_PRODUCT_VIEW_TYPE) {
            return new ImageProductViewHolder(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_item_new_subscription, parent, false));
        } else
            return null;

    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof HeaderViewHolder) {
            ((HeaderViewHolder) holder).setData((String) items.get(position));
        } else if (holder instanceof ImageProductViewHolder) {
            ((ImageProductViewHolder) holder).setData((ProductsItem) items.get(position));
        }
    }

    @Override
    public int getItemCount() {
        if (items != null) {
            return items.size();
        } else {
            return 0;
        }
    }

    public class HeaderViewHolder extends RecyclerView.ViewHolder {
        private TextView mHeaderTextView;
        private View mLayout;

        public HeaderViewHolder(View itemView) {
            super(itemView);
            mLayout = itemView;
            mHeaderTextView = itemView.findViewById(R.id.headerTextView);
        }

        public void setData(String header) {
            mHeaderTextView.setText(header);

        }
    }

    public class ImageProductViewHolder extends RecyclerView.ViewHolder {
        private TextView mProductNameTextView;
        private View mLayout;
        private ImageView mProductIcon;

        public ImageProductViewHolder(View itemView) {
            super(itemView);
            mLayout = itemView;
            mProductNameTextView = itemView.findViewById(R.id.productNameTextView);
            mProductIcon = itemView.findViewById(R.id.productIcon);
        }

        public void setData(ProductsItem productsItem) {
            mProductNameTextView.setText(productsItem.type);
            Glide.with(mProductIcon.getContext()).
                    load(productsItem.image).into(mProductIcon);

        }
    }
}
