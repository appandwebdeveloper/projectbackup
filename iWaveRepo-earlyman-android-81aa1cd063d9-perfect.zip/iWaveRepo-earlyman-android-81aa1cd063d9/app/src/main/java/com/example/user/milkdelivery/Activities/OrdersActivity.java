package com.example.user.milkdelivery.Activities;

import android.content.Intent;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.View;
import android.widget.ProgressBar;

import com.example.user.milkdelivery.Adapters.DealersAdapter;
import com.example.user.milkdelivery.Adapters.OrdersAdapter;
import com.example.user.milkdelivery.NetworkCalls.CallsForOrders;
import com.example.user.milkdelivery.R;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class OrdersActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener, CallsForOrders.CallBack {
    private RecyclerView mRecyclerView;
    private OrdersAdapter mOrdersAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private CallsForOrders mCallsForOrders;
    private Timer mTimer;
    private ProgressBar mProgressBar;
    private Runnable mRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);
        mRecyclerView = findViewById(R.id.orderRecyclerView);
        mSwipeRefreshLayout = findViewById(R.id.swipeToRefresh);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setHasFixedSize(true);
        mOrdersAdapter = new OrdersAdapter();
        mRecyclerView.setAdapter(mOrdersAdapter);
        mProgressBar = findViewById(R.id.progressBar);
       new DealersAdapter();
        mSwipeRefreshLayout.setOnRefreshListener(this);
        final Handler handler = new Handler();
        mRunnable = new Runnable() {
            @Override
            public void run() {

                CallsForOrders.getInstance().getTodayOrderValues(OrdersActivity.this);
                mSwipeRefreshLayout.setOnRefreshListener(OrdersActivity.this);
            }
        };

        mTimer = new Timer();
        mTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(mRunnable);
            }
        }, 1500, 1500);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.profile_menu,menu);
        return true;
    }

    @Override
    public void onRefresh() {
        if (CallsForOrders.getInstance() != null)
            CallsForOrders.getInstance().getTodayOrderValues(this);
    }

    @Override
    public void onTodayOrdersSuccess(final List<Object> today) {
        this.runOnUiThread(new Runnable() {
            public void run() {
                if (mOrdersAdapter != null)
                    mOrdersAdapter.setData(today);
                new DealersAdapter().setData(today);
                mSwipeRefreshLayout.setRefreshing(false);
                mProgressBar.bringToFront();
            }
        });
        mRunnable = new Runnable() {
            @Override
            public void run() {
                mProgressBar.setVisibility(View.GONE);
                mTimer.cancel();
            }
        };
    }
}
