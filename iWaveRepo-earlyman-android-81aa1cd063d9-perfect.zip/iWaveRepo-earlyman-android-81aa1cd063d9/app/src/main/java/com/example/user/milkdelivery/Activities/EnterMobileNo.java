package com.example.user.milkdelivery.Activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.user.milkdelivery.R;

public class EnterMobileNo extends Activity {
    private Button mSendOTPButton;
    private TextView mSignInTextView;
    private ImageView mBackNavigationImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_mobile_no);
        mSignInTextView = findViewById(R.id.signInTextView);
        mBackNavigationImageView = findViewById(R.id.backNavigationImageView);
        mSendOTPButton = findViewById(R.id.oTPButton);
        mSendOTPButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(EnterMobileNo.this, OTPVerification.class));
            }
        });

        mSignInTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(EnterMobileNo.this, MainActivity.class));
            }
        });
        mBackNavigationImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EnterMobileNo.this, AddAddress.class));
            }
        });
    }

}
