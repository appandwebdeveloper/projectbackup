package com.example.user.milkdelivery.Activities;

import android.app.Activity;
import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.ContextCompat;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.user.milkdelivery.R;

public class MainActivity extends Activity {
    private Button mSignINButton;
    private EditText mUsernameEditText, mPasswordEditText;
    private TextView mUsernameTextView, mPasswordTextView, mSignUpTextView;
    private ConstraintLayout mBackgroundChangeConstraintLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mPasswordEditText = findViewById(R.id.passwordEditText);
        mSignINButton = findViewById(R.id.signInButton);
        mUsernameEditText = findViewById(R.id.usernameEditText);
        mPasswordTextView = findViewById(R.id.passwordTextView);
        mUsernameTextView = findViewById(R.id.usernameTextView);
        mSignUpTextView = findViewById(R.id.signUpTextView);
        mBackgroundChangeConstraintLayout = findViewById(R.id.backgroundChange);
        mUsernameTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mUsernameEditText.setText("Sahana.b@inspiringwave.in");
                mPasswordEditText.setText("iwave123");
                mBackgroundChangeConstraintLayout.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.sign_in_img));
            }
        });
        mUsernameEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mUsernameEditText.setText("Sahana.b@inspiringwave.in");
                mPasswordEditText.setText("iwave123");
                mBackgroundChangeConstraintLayout.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.sign_in_img));
            }
        });
        mPasswordTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mUsernameEditText.setText("Sahana.b@inspiringwave.in");
                mPasswordEditText.setText("iwave123");
                mBackgroundChangeConstraintLayout.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.sign_in_img));
            }
        });
        mPasswordEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mUsernameEditText.setText("Sahana.b@inspiringwave.in");
                mPasswordEditText.setText("iwave123");
                mBackgroundChangeConstraintLayout.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.sign_in_img));
            }
        });
        mSignINButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(mUsernameEditText.getText().toString(), mPasswordEditText.getText().toString());


            }
        });
        mSignUpTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openSecond = new Intent(MainActivity.this, SignUpActivity.class);
                startActivity(openSecond);
            }
        });
    }

    private void validate(String name, String password) {
        if (name.equals("Sahana.b@inspiringwave.in") && password.equals("iwave123")) {
            Intent openSecond = new Intent(MainActivity.this, OrdersActivity.class);
            startActivity(openSecond);
        }
    }
}

