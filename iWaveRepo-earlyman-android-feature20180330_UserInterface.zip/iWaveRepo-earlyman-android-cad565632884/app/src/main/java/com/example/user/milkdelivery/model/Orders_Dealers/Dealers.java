package com.example.user.milkdelivery.model.Orders_Dealers;


import com.google.gson.annotations.SerializedName;


public class Dealers {

	@SerializedName("personName")
	public String personName;

	@SerializedName("phoneNumber")
	public String phoneNumber;

	@SerializedName("imageUrl")
	public String imageUrl;

	@SerializedName("locality")
	public String locality;
}