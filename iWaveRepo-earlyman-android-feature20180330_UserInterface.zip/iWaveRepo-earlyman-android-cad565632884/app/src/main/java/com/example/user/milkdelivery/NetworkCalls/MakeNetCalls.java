package com.example.user.milkdelivery.NetworkCalls;


import com.example.user.milkdelivery.model.New_Subscription_json.ProductType;
import com.google.gson.Gson;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by User on 3/8/2018.
 */

public class MakeNetCalls {
    private OkHttpClient mClient ;
    private List<Object> mItems;
    private ProductType mProductType;
    private String mResponse;
    private CallBack mCallBack;
    private static MakeNetCalls sMakeNetCalls;

    public static MakeNetCalls getInstance() {
        if (sMakeNetCalls == null)
            sMakeNetCalls = new MakeNetCalls();
        return sMakeNetCalls;
    }

    public void getProductValues(final CallBack callBack) {
        mClient = new OkHttpClient();
        mItems = new ArrayList<>();
        Request request = new Request.Builder().url("http://www.mocky.io/v2/5aaf55812d00004f006efcbe").build();
        mClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Request request, IOException e) {
                e.getMessage();
            }

            @Override
            public void onResponse(Response response) throws IOException {
                mResponse = response.body().string();
                Gson gson = new Gson();
                mProductType = gson.fromJson(mResponse, ProductType.class);
                mItems.clear();
                mItems.addAll(mProductType.products);
                if (callBack != null)
                    callBack.onSuccess(mItems);
            }
        });

    }

    public interface CallBack {
        void onSuccess(List<Object> productItems);

    }
}
