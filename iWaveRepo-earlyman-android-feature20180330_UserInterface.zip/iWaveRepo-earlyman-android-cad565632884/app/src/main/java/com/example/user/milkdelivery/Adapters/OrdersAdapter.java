package com.example.user.milkdelivery.Adapters;

import android.app.AlertDialog;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.user.milkdelivery.R;
import com.example.user.milkdelivery.model.Orders_Dealers.TodaysOrder;
import com.example.user.milkdelivery.model.Orders_Dealers.TomorrowHeaderButton;
import com.example.user.milkdelivery.model.Orders_Dealers.TomorrowsOrder;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by User on 3/12/2018.
 */

public class OrdersAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<Object> mOrdersList = new ArrayList<>();
    private static final int HEADER_VIEW_TYPE = 0;
    private static final int HEADER_BUTTON_VIEW_TYPE = 2;
    private static final int TODAY_ORDERS_VIEW_TYPE = 1;
    private static final int TOMORROW_ORDERS_VIEW_TYPE = 3;
    private Date mDate = new Date();
    CharSequence mCurrentDate = android.text.format.DateFormat.format("MM/dd/yyyy ", mDate.getTime());

    public void setData(List<Object> mOrdersList) {
        this.mOrdersList = mOrdersList;
        notifyDataSetChanged();

    }

    //here check the getting item viewtype  and return that viewtype in order
    @Override
    public int getItemViewType(int position) {
        if (mOrdersList.get(position) instanceof String) {
            return HEADER_VIEW_TYPE;
        } else if (mOrdersList.get(position) instanceof TomorrowHeaderButton) {
            return HEADER_BUTTON_VIEW_TYPE;
        } else if (mOrdersList.get(position) instanceof TodaysOrder) {
            return TODAY_ORDERS_VIEW_TYPE;
        }
        return TOMORROW_ORDERS_VIEW_TYPE;

    }

    public void setData(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof HeaderViewHolder) {
            ((HeaderViewHolder) holder).setData((String) mOrdersList.get(position));
        } else if (holder instanceof TodayOrdersViewHolder) {
            ((TodayOrdersViewHolder) holder).setData((TodaysOrder) mOrdersList.get(position));
        } else if (holder instanceof HeaderButtonViewHolder) {
            ((HeaderButtonViewHolder) holder).setData((TomorrowHeaderButton) mOrdersList.get(position));
        } else if (holder instanceof TomorrowsOrdersViewHolder) {
            ((TomorrowsOrdersViewHolder) holder).setData((TomorrowsOrder) mOrdersList.get(position));
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        switch (viewType) {
            case HEADER_VIEW_TYPE:
                return new HeaderViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.header, parent, false));
            case TODAY_ORDERS_VIEW_TYPE:
                return new TodayOrdersViewHolder(LayoutInflater.from(parent.getContext()).
                        inflate(R.layout.list_item_orders_today, parent, false));
            case HEADER_BUTTON_VIEW_TYPE:
                return new HeaderButtonViewHolder(LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.header_button, parent, false));
            case TOMORROW_ORDERS_VIEW_TYPE:
                return new TomorrowsOrdersViewHolder(LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.list_item_orders_tomorrows, parent, false));
            default:
                return null;
        }

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        setData(holder, position);
    }

    @Override
    public int getItemCount() {
        return (mOrdersList != null) ? (mOrdersList.size()) : 0;
    }

    //it's today's header view.
    public class HeaderViewHolder extends RecyclerView.ViewHolder {
        private TextView mTodayHeaderTextView;
        private View mLayout;

        public HeaderViewHolder(View itemView) {
            super(itemView);
            mLayout = itemView;
            mTodayHeaderTextView = itemView.findViewById(R.id.toadayHeaderTextView);
        }

        public void setData(String todayHeader) {
            mTodayHeaderTextView.setText(todayHeader);
        }
    }

    //it contain  image of product,product's brand name and price of brand views.
    public class TodayOrdersViewHolder extends RecyclerView.ViewHolder {
        private TextView mBrandNameTextView, mPriceTextView;
        private ImageView mBrandImageView, mQuestionImageView;
        private View mLayout;

        public TodayOrdersViewHolder(View itemView) {
            super(itemView);
            mLayout = itemView;
            mBrandImageView = itemView.findViewById(R.id.brandImageView);
            mBrandNameTextView = itemView.findViewById(R.id.brandNameTextView);
            mPriceTextView = itemView.findViewById(R.id.priceTextView);
            mQuestionImageView = itemView.findViewById(R.id.questionImageView);
        }

        public void setData(TodaysOrder todaysOrder) {
            mBrandNameTextView.setText(todaysOrder.name);
            mPriceTextView.setText(todaysOrder.price);
            Glide.with(mBrandImageView.getContext()).load(todaysOrder.imageUrl).into(mBrandImageView);
        }
    }

    //here  tomorrow header and button views
    public class HeaderButtonViewHolder extends RecyclerView.ViewHolder {
        private TextView mTomorrowHeaderTextView;
        private Button mHolidayButton;
        private View mLayout;

        public HeaderButtonViewHolder(View itemView) {
            super(itemView);
            mLayout = itemView;
            mTomorrowHeaderTextView = itemView.findViewById(R.id.tomorrowHeaderTextView);
            mHolidayButton = itemView.findViewById(R.id.holidayButton);
        }

        public void setData(TomorrowHeaderButton tomorrowHeaderButton) {
            mTomorrowHeaderTextView.setText(tomorrowHeaderButton.header);
            mHolidayButton.setText(tomorrowHeaderButton.buttonName);
        }
    }

    // product's image view and product name and price textviews and edittext  view for entering quantity
    public class TomorrowsOrdersViewHolder extends RecyclerView.ViewHolder {
        private TextView mBrandNameTextView,mQuantityTextView, mPriceTextView;
        private ImageView mBrandImageView, mPlusImageView, mMinusImageView;
        private RelativeLayout mOrderTomorrowRelativeLayout;
      //  private LinearLayout mTomorrowLinearLayout;
        //private Button mCancelOrderButton, mDeliverToNeighbourButton;
        private View mLayout;

        public TomorrowsOrdersViewHolder(View itemView) {
            super(itemView);
            mLayout = itemView;
            mBrandImageView = itemView.findViewById(R.id.brandImageView);
            mBrandNameTextView = itemView.findViewById(R.id.brandNameTextView);
            mPriceTextView = itemView.findViewById(R.id.priceTextView);
            mPlusImageView = itemView.findViewById(R.id.plusImageView);
            mMinusImageView = itemView.findViewById(R.id.minusImageView);
            mQuantityTextView = itemView.findViewById(R.id.quantityTextView);
            mOrderTomorrowRelativeLayout = itemView.findViewById(R.id.orderTomorrowLayout);
            //mCancelOrderButton = itemView.findViewById(R.id.cancelOrderButton);
          //  mDeliverToNeighbourButton = itemView.findViewById(R.id.deliverToNeighbourbutton);
           // mTomorrowLinearLayout=itemView.findViewById(R.id.tomorrowLinearLayout);
        }

        public void setData(TomorrowsOrder tomorrowsOrder) {
            mBrandNameTextView.setText(tomorrowsOrder.name);
            mPriceTextView.setText(tomorrowsOrder.price);
            Glide.with(mBrandImageView.getContext()).load(tomorrowsOrder.imageUrl).into(mBrandImageView);
            mQuantityTextView.setText(tomorrowsOrder.quantity + "");
            mMinusImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                }
            });
            mOrderTomorrowRelativeLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //LayoutInflater.from(v.getContext()).inflate(R.layout.onclick_of_tomorrow_display,null);
                   // mCancelOrderButton.setVisibility(View.VISIBLE);
                   // mDeliverToNeighbourButton.setVisibility(View.VISIBLE);
                  //  mTomorrowLinearLayout.setVisibility(View.VISIBLE);
                    /*mCancelOrderButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            AlertDialog alertDialog = new AlertDialog.Builder(v.getContext()).create();
                            alertDialog.setView(View.inflate(v.getContext(), R.layout.alert_message, null));
                            alertDialog.show();
                        }
                    });*/
                }

            });

        }
    }

    //here start list of dealer information.
    //text view for dealers'header and start dealers recyclerview
  /* public class DealersHeaderViewHolder extends RecyclerView.ViewHolder {
        private TextView mDealersTextView;
        private View mLayout;

        public DealersHeaderViewHolder(View itemView) {
            super(itemView);
            mLayout = itemView;
            mDealersTextView = itemView.findViewById(R.id.dealersTextView);
        }

        // here add the header of dealers
        public void setData(String string) {
            mDealersTextView.setText(string);
        }

    }

    public class DealersViewHolder extends RecyclerView.ViewHolder {
        private TextView mDealersNameTextView;
        private CircleImageView mProfileImage;
        private EditText mDealerNumberEditText;
        private View mLayout;

        public DealersViewHolder(View itemView) {
            super(itemView);
            mLayout = itemView;
            mDealersNameTextView = itemView.findViewById(R.id.dealerNameTextView);
            mDealerNumberEditText = itemView.findViewById(R.id.dealerNumberEditText);
            mProfileImage = itemView.findViewById(R.id.profileImage);
        }

        public void setData(Dealers dealersItem) {
            mDealerNumberEditText.setText(dealersItem.phoneNumber);
            mDealersNameTextView.setText(dealersItem.personName);
            Glide.with(mProfileImage.getContext()).load(dealersItem.imageUrl).into(mProfileImage);
        }

    }*/
}
