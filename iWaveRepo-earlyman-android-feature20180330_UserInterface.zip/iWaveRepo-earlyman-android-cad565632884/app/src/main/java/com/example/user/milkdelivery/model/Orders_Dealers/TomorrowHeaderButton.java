package com.example.user.milkdelivery.model.Orders_Dealers;

/**
 * Created by User on 3/21/2018.
 */

public class TomorrowHeaderButton {
    public String header,buttonName;

    public TomorrowHeaderButton(String header, String buttonName) {
        this.header = header;
        this.buttonName = buttonName;
    }

}
