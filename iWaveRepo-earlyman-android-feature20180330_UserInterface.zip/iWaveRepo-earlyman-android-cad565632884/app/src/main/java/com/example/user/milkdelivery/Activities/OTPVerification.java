package com.example.user.milkdelivery.Activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.user.milkdelivery.R;

public class OTPVerification extends Activity {
    private Button mSignUpButton;
    private TextView mResendTextView, mSignInTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otpverification);
        mSignUpButton = findViewById(R.id.signUpButton);
        mResendTextView = findViewById(R.id.resendTextView);
        mSignUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openSecond = new Intent(OTPVerification.this, Subscribe.class);
                startActivity(openSecond);
            }
        });
        mSignInTextView = findViewById(R.id.signInTextView);
        mSignInTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openSecond = new Intent(OTPVerification.this, MainActivity.class);
                startActivity(openSecond);
            }
        });
        mResendTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }
}
