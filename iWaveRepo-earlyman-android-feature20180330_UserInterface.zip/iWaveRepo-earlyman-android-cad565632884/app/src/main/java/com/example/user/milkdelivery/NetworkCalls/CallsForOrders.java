package com.example.user.milkdelivery.NetworkCalls;

import com.example.user.milkdelivery.model.Orders_Dealers.OrdersDealers;
import com.example.user.milkdelivery.model.Orders_Dealers.TomorrowHeaderButton;
import com.google.gson.Gson;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by User on 3/15/2018.
 */

public class CallsForOrders {
    private OkHttpClient mClient = new OkHttpClient();
    private List<Object> mItems = new ArrayList<>();
    private OrdersDealers mOrdersDealers;
    private String mResponse;
    private CallBack mCallBack;
    private TomorrowHeaderButton mTomorrowHeaderButton=new TomorrowHeaderButton("Tomorrows Order","Holiday");
    private static CallsForOrders sCallsForOrders;
    private Request mRequest = new Request.Builder().url("http://www.mocky.io/v2/5aaf64b02d00004d006efd0a").build();

    public static CallsForOrders getInstance() {
        if (sCallsForOrders == null)
            sCallsForOrders = new CallsForOrders();
        return sCallsForOrders;
    }

    public void getTodayOrderValues(final CallBack callBack) {
        mClient.newCall(mRequest).enqueue(new Callback() {
            @Override
            public void onFailure(Request request, IOException e) {
                e.getMessage();
            }

            @Override
            public void onResponse(Response response) throws IOException {
                mResponse = response.body().string();
                Gson gson = new Gson();
                mOrdersDealers = gson.fromJson(mResponse, OrdersDealers.class);
                mItems.clear();
                mItems.add("Todays Order");
                mItems.addAll(mOrdersDealers.todaysOrder);
                mItems.add(mTomorrowHeaderButton);
                mItems.addAll(mOrdersDealers.tomorrowsOrder);
                if (callBack != null)
                    callBack.onTodayOrdersSuccess(mItems);
            }

        });

    }

   /*public void getTomorrowOrderValues(final CallBack callBack) {

        mClient.newCall(mRequest).enqueue(new Callback() {
            @Override
            public void onFailure(Request request, IOException e) {
                e.getMessage();
            }

            @Override
            public void onResponse(Response response) throws IOException {
                mResponse = response.body().string();
                Gson gson = new Gson();
                mOrdersDealers = gson.fromJson(mResponse, OrdersDealers.class);
                mItems.addAll(mOrdersDealers.tomorrowsOrder);
                if (callBack != null)
                    callBack.onTomorrowOrdersSuccess(mItems);
            }

        });

    }

   /* public void getDealersValues(final CallBack callBack) {
        mClient.newCall(mRequest).enqueue(new Callback() {
            @Override
            public void onFailure(Request request, IOException e) {
                e.getMessage();
            }

            @Override
            public void onResponse(Response response) throws IOException {
                mResponse = response.body().string();
                Gson gson = new Gson();
                mOrdersDealers = gson.fromJson(mResponse, OrdersDealers.class);
                mItems.addAll(mOrdersDealers.dealers);
                if (callBack != null)
                    callBack.onDealersSuccess(mItems);
            }

        });
    }*/

    public interface CallBack {
        //void onDealersSuccess(List<Object> dealers);
        void onTodayOrdersSuccess(List<Object> today);
       // void onTomorrowOrdersSuccess(List<Object> tomorrow);
    }
}
