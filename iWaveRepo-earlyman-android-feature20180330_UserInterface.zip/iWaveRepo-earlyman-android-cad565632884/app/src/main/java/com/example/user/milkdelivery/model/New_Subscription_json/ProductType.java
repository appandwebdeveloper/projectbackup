package com.example.user.milkdelivery.model.New_Subscription_json;

import java.util.List;
import com.google.gson.annotations.SerializedName;


public class ProductType{

	@SerializedName("products")
	public List<ProductsItem> products;
}