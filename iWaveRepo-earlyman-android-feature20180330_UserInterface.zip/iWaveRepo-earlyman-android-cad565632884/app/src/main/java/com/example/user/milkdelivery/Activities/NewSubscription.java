package com.example.user.milkdelivery.Activities;

import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ProgressBar;

import com.example.user.milkdelivery.NetworkCalls.MakeNetCalls;
import com.example.user.milkdelivery.Adapters.NewSubscriptionAdapter;
import com.example.user.milkdelivery.R;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class NewSubscription extends AppCompatActivity implements MakeNetCalls.CallBack, SwipeRefreshLayout.OnRefreshListener {
    private RecyclerView mRecyclerView;
    private NewSubscriptionAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private MakeNetCalls mMakeNetCalls;
    private ProgressBar mProgressBar;
    private Timer mTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_subscription_recyclerview);
        mProgressBar = findViewById(R.id.progressBar);
        mRecyclerView = findViewById(R.id.newSubscriptionRecyclerview);
        mSwipeRefreshLayout = findViewById(R.id.swipeToRefresh);
        mLayoutManager = new LinearLayoutManager(getApplicationContext());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setHasFixedSize(true);
        final Handler handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                mProgressBar.setVisibility(View.GONE);
                MakeNetCalls.getInstance().getProductValues(NewSubscription.this);
                mSwipeRefreshLayout.setOnRefreshListener(NewSubscription.this);
                mTimer.cancel();
            }
        };

        mTimer = new Timer();
        mTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(runnable);
            }
        }, 1000, 1000);
        mAdapter = new NewSubscriptionAdapter();
        mRecyclerView.setAdapter(mAdapter);
    }

    @Override
    public void onSuccess(final List<Object> productItems) {
        this.runOnUiThread(new Runnable() {
            public void run() {
                if (mAdapter != null)
                    mAdapter.setData(productItems);
                mSwipeRefreshLayout.setRefreshing(false);

            }
        });

    }

    @Override
    public void onRefresh() {
        if (MakeNetCalls.getInstance() != null)
            MakeNetCalls.getInstance().getProductValues(this);
    }
}
