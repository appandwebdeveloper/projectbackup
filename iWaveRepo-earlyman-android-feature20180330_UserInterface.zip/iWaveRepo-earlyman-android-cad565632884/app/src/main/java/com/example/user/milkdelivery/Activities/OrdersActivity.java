package com.example.user.milkdelivery.Activities;

import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;

import com.example.user.milkdelivery.Adapters.OrdersAdapter;
import com.example.user.milkdelivery.NetworkCalls.CallsForOrders;
import com.example.user.milkdelivery.R;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class OrdersActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener, CallsForOrders.CallBack {
    private RecyclerView mRecyclerView;
    private OrdersAdapter mOrdersAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private CallsForOrders mCallsForOrders;
    private Timer mTimer;
    private ProgressBar mProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);
        mRecyclerView = findViewById(R.id.orderRecyclerView);
        mSwipeRefreshLayout = findViewById(R.id.swipeToRefresh);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setHasFixedSize(true);
        mOrdersAdapter = new OrdersAdapter();
        mRecyclerView.setAdapter(mOrdersAdapter);
        mProgressBar = findViewById(R.id.progressBar);

        mSwipeRefreshLayout.setOnRefreshListener(this);
        final Handler handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {

                mProgressBar.setVisibility(View.GONE);
                CallsForOrders.getInstance().getTodayOrderValues(OrdersActivity.this);
                mSwipeRefreshLayout.setOnRefreshListener(OrdersActivity.this);
                mTimer.cancel();
            }
        };

        mTimer = new Timer();
        mTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(runnable);
            }
        }, 1000, 1000);
    }

    @Override
    public void onRefresh() {
        if (CallsForOrders.getInstance() != null)
            CallsForOrders.getInstance().getTodayOrderValues(this);
    }

    @Override
    public void onTodayOrdersSuccess(final List<Object> today) {
        this.runOnUiThread(new Runnable() {
            public void run() {
                if (mOrdersAdapter != null)
                    mOrdersAdapter.setData(today);
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
    }
}
