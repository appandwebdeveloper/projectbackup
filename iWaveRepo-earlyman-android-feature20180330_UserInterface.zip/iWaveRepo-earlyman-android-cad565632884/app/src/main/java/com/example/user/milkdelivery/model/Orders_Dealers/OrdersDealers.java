package com.example.user.milkdelivery.model.Orders_Dealers;

import java.util.List;

import com.google.gson.annotations.SerializedName;


public class OrdersDealers{

	@SerializedName("todaysOrder")
	public List<TodaysOrder> todaysOrder;

	@SerializedName("dealers")
	public List<Dealers> dealers;

	@SerializedName("tomorrowsOrder")
	public List<TomorrowsOrder> tomorrowsOrder;
}